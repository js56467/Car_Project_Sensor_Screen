/****************************************************************************
 * 项目名称: 基于51单片机的单相交流电参数测量系统设计 (51 仿真, 私单)
 * MCU      : STC89C52 (Proteus 用 AT89C52 替代, 引脚/内核兼容) @ 12 MHz
 * 编译器   : Keil C51
 *
 * == 设计任务 (课题一: 单相交流电参数测量系统) =============================
 *   (1) 基本监测: 实时测量交流电压有效值 U、电流有效值 I
 *   (2) 功率计算: 自动计算并显示有功功率 P、视在功率 S、功率因数 PF
 *   (3) 数据显示: LCD1602 实时显示电压、电流、功率因数 (+ 有功/视在功率)
 *   (4) 状态指示: LED 指示功率因数高低 (PF>0.95 绿灯亮, PF<0.85 红灯亮)
 *
 * == 仿真约定 (用滑动变阻器模拟交流电参数, 私单需求) ======================
 *   真实交流参数测量需采样工频波形 + 过零检测算相位差; 仿真版简化为:
 *   3 个滑动变阻器(电位器)分压 0~5V, 经 TLC1543 转成数字量, 分别模拟:
 *     RV1 -> AIN0 -> 电压有效值 U   (0~5V 映射 0~250.0V)
 *     RV2 -> AIN1 -> 电流有效值 I   (0~5V 映射 0~5.00A)
 *     RV3 -> AIN2 -> 功率因数 cosφ  (0~5V 映射 0.00~1.00)
 *   视在功率 S = U × I            (VA)
 *   有功功率 P = S × cosφ = U×I×cosφ (W)
 *   功率因数 PF = cosφ            (直接来自 RV3)
 *   ★ 全整数定点运算, 无 float (Keil C51 浮点吃 code/RAM; 中间量用 ulong 防 16 位溢出)
 *   ★ 仿真版 ADC 默认正向映射 (adc 越大值越大); 如实测方向反了再加 (1023-adc)
 *
 * == 接线 ===================================================================
 *   TLC1543  SDO -> P1.0  ADDR -> P1.1  CS\ -> P1.2  CLK -> P1.3  EOC -> P1.4
 *            AIN0 <- RV1(电压)  AIN1 <- RV2(电流)  AIN2 <- RV3(功率因数)
 *            REF+ -> +5V   REF- -> GND   (满量程 5V 对应 1023)
 *   LCD1602  D0-D7 -> P0.0-P0.7 (RESPACK-8 上拉 +5V)
 *            RS -> P2.0   RW -> P2.1   EN -> P2.2   VEE(V0) -> GND
 *   LED_GRN  -> P2.4  (绿灯, 高有效 1=亮, PF>0.95 亮, 功率因数合格)
 *   LED_RED  -> P2.5  (红灯, 高有效 1=亮, PF<0.85 亮, 功率因数过低告警)
 *
 * == 显示 (LCD1602 两页自动轮显, 每页约 2.5s; LED 实时不受轮显影响) ========
 *   页1: 行1 "U=250.0V I=5.00A"   行2 "PF=0.92  GREEN  "
 *   页2: 行1 "P=1250W S=1250VA"   行2 "1-Ph AC PwrMeter"
 ****************************************************************************/

#include <reg52.h>
#include <intrins.h>
#include <stdio.h>

#define uchar unsigned char
#define uint  unsigned int
#define ulong unsigned long

/* ==================== TLC1543 串行 10 位 ADC (P1.0~P1.4) ==================== */
sbit TLC_SDO  = P1^0;     /* DATA OUT  ADC->MCU   (输入) */
sbit TLC_ADDR = P1^1;     /* ADDRESS   MCU->ADC   (输出, 4 位通道地址) */
sbit TLC_CS   = P1^2;     /* CS\ 片选  低有效      (输出) */
sbit TLC_CLK  = P1^3;     /* I/O CLK              (输出) */
sbit TLC_EOC  = P1^4;     /* EOC 转换完成 ADC->MCU (输入) */

/* ==================== LCD1602 (数据 P0, 控制 P2.0/1/2) ==================== */
sbit LCD_RS = P2^0;
sbit LCD_RW = P2^1;
sbit LCD_EN = P2^2;

/* ==================== 双 LED 指示 (高有效, 1=亮) ==================== */
sbit LED_GRN = P2^4;      /* 绿灯: 功率因数 PF > 0.95 时亮 (合格) */
sbit LED_RED = P2^5;      /* 红灯: 功率因数 PF < 0.85 时亮 (过低告警) */

/* ==================== TLC1543 通道 (只用前 3 路) ==================== */
#define CH_VOLT  0        /* AIN0 <- RV1 电压有效值 U */
#define CH_CURR  1        /* AIN1 <- RV2 电流有效值 I */
#define CH_PF    2        /* AIN2 <- RV3 功率因数 cosφ */

/* ==================== 量程 (0~5V 满量程对应的物理量, 定点放大) ==================== */
#define U_FULL   2500U    /* 电压满量程 250.0V (0.1V 单位) */
#define I_FULL   500U     /* 电流满量程 5.00A  (0.01A 单位) */
#define PF_FULL  100U     /* 功率因数满量程 1.00 (0.01 单位) */

/* ==================== 主循环节拍 (1ms 基础 tick, 慢任务分频) ==================== */
#define LOOP_MS     1U    /* 主循环基础节拍 1ms */
#define ADC_TICKS   100U  /* 100ms 采一次 ADC + 算功率 + 刷 LED (LED 实时) */
#define LCD_TICKS   250U  /* 250ms 刷一次 LCD 当前页 */
#define PAGE_TICKS  2500U /* 2.5s  切换一次显示页 */

/* ==================== 全局状态 (整数定点) ==================== */
uint  g_U_d1    = 0;      /* 电压 ×10  (0.1V),  0~2500 = 0~250.0V */
uint  g_I_c2    = 0;      /* 电流 ×100 (0.01A), 0~500  = 0~5.00A  */
uchar g_pf_d2   = 0;      /* 功率因数 ×100 (0.01), 0~100 = 0.00~1.00 */
uint  g_S_va    = 0;      /* 视在功率 (VA), 0~1250 */
uint  g_P_w     = 0;      /* 有功功率 (W),  0~1250 */
uchar g_pfState = 0;      /* 灯状态: 0=一般(都灭) 1=绿(>0.95) 2=红(<0.85) */
uchar g_page    = 0;      /* 当前显示页: 0 / 1 */

/* LCD 行缓冲放 idata (避免局部 char[] 撑爆 51 SMALL 模式 data 区) */
idata char g_line1[17];
idata char g_line2[17];

/* ==================== 延时 (12MHz, 仿真够用) ==================== */
void Delay_ms(uint xms)  { uint i, j; for (i = 0; i < xms; i++) for (j = 0; j < 120; j++); }
void Delay_us(uchar xus) { while (xus--) _nop_(); }

/* ==================== LCD1602 驱动 (母本: 测温系统, 逐字沿用) ==================== */
void LCD_Write_Cmd(uchar cmd)
{
    LCD_RS = 0; LCD_RW = 0; P0 = cmd;
    LCD_EN = 1; Delay_us(20); LCD_EN = 0; Delay_ms(1);
}
void LCD_Write_Data(uchar dat)
{
    LCD_RS = 1; LCD_RW = 0; P0 = dat;
    LCD_EN = 1; Delay_us(20); LCD_EN = 0; Delay_us(40);
}
void LCD_Init(void)
{
    Delay_ms(15);
    LCD_Write_Cmd(0x38);      /* 8 位接口, 2 行, 5x7 点阵 */
    LCD_Write_Cmd(0x0C);      /* 显示开, 无光标 */
    LCD_Write_Cmd(0x06);      /* 写后地址自增 */
    LCD_Write_Cmd(0x01);      /* 清屏 */
    Delay_ms(2);
}
void LCD_GotoXY(uchar row, uchar col)   /* row=0 第1行 / row=1 第2行, col=0~15 */
{
    if (row == 0) LCD_Write_Cmd(0x80 | col);
    else          LCD_Write_Cmd(0xC0 | col);
}
void LCD_Write_Str(uchar row, uchar col, char *s)
{
    LCD_GotoXY(row, col);
    while (*s) LCD_Write_Data(*s++);
}

/* ==================== TLC1543 时序 (母本: 数字电压表, 10 个时钟) ====================
 * MSB 先出. CS 拉低后 SDO 给出"上一次转换"结果的 MSB; 之后 10 个时钟, 每个时钟前读
 * 1 位(共 10 位); 前 4 个时钟同时把 4 位通道地址(MSB 先)从 ADDR 送进去; CS 拉高 ->
 * 启动对新选通道的转换. ★返回值是"上一次寻址通道"的结果, 故对同一通道连读两次取后值. */
uint TLC1543_Xfer(uchar ch)
{
    uchar i;
    uint  dat = 0;
    ch <<= 4;                          /* 4 位通道号移到高 4 位, MSB 先发 */
    TLC_CS = 1; TLC_CLK = 0; TLC_CS = 0;   /* 片选有效, SDO 出 MSB */
    for (i = 0; i < 10; i++)
    {
        dat <<= 1;
        if (TLC_SDO) dat |= 0x0001;    /* 读 1 位数据 (MSB 先) */
        if (ch & 0x80) TLC_ADDR = 1;   /* 送 1 位地址 (MSB 先, 仅前 4 位有效) */
        else           TLC_ADDR = 0;
        ch <<= 1;
        TLC_CLK = 1; _nop_();          /* 上升沿: 锁存地址位 */
        TLC_CLK = 0; _nop_();          /* 下降沿: SDO 切到下一位 */
    }
    TLC_CS = 1;                        /* 拉高启动转换 */
    return dat;                        /* 10 位结果 0~1023 */
}

/* 读指定通道电压原始值 (双读: 第1次寻址+启动转换, 等转换完, 第2次取重复通道值) */
uint TLC1543_Read(uchar ch)
{
    uint to = 0;
    TLC1543_Xfer(ch);                  /* 寻址 ch + 启动 ch 转换 (返回值丢弃) */
    Delay_us(30);                      /* 等转换 (TLC1543 约 21us) */
    while (!TLC_EOC && ++to < 2000);   /* EOC 高=转换完成 (带超时, 防仿真死等) */
    return TLC1543_Xfer(ch);           /* 再读 ch 的转换结果 */
}

/* ==================== 采样 + 功率计算 (全整数, ulong 防溢出, 无 float) ==================== */
void Sample_And_Compute(void)
{
    uint  adcU, adcI, adcPF;
    ulong tmp;

    adcU  = TLC1543_Read(CH_VOLT);     /* 0~1023 */
    adcI  = TLC1543_Read(CH_CURR);
    adcPF = TLC1543_Read(CH_PF);

    /* ADC 原始值 -> 物理量 (★默认正向; +511 四舍五入到最近刻度) */
    g_U_d1  = (uint) (((ulong)adcU  * U_FULL  + 511UL) / 1023UL);   /* 0.1V, 0~2500 */
    g_I_c2  = (uint) (((ulong)adcI  * I_FULL  + 511UL) / 1023UL);   /* 0.01A, 0~500 */
    g_pf_d2 = (uchar)(((ulong)adcPF * PF_FULL + 511UL) / 1023UL);   /* 0.01, 0~100 */

    /* 视在功率 S = U × I (VA) = (U_d1/10)×(I_c2/100) = U_d1×I_c2/1000 */
    tmp    = (ulong)g_U_d1 * (ulong)g_I_c2;     /* max 2500×500 = 1,250,000 (须 ulong) */
    g_S_va = (uint)((tmp + 500UL) / 1000UL);    /* 四舍五入, 0~1250 VA */

    /* 有功功率 P = S × cosφ (W) = S_va × (pf_d2/100) */
    tmp   = (ulong)g_S_va * (ulong)g_pf_d2;     /* max 1250×100 = 125,000 */
    g_P_w = (uint)((tmp + 50UL) / 100UL);       /* 四舍五入, 0~1250 W */
}

/* ==================== LED 指示 (功率因数高低, 实时刷新) ==================== */
void Update_LED(void)
{
    if (g_pf_d2 > 95) {                /* PF > 0.95 -> 绿灯 (合格) */
        LED_GRN = 1; LED_RED = 0; g_pfState = 1;
    } else if (g_pf_d2 < 85) {         /* PF < 0.85 -> 红灯 (过低告警) */
        LED_GRN = 0; LED_RED = 1; g_pfState = 2;
    } else {                           /* 0.85 <= PF <= 0.95 -> 都灭 (一般) */
        LED_GRN = 0; LED_RED = 0; g_pfState = 0;
    }
}

/* ==================== LCD 显示当前页 (每行定长 16 字符, 等宽覆盖防残影) ==================== */
void LCD_ShowPage(uchar page)
{
    if (page == 0) {
        /* 页1: 电压 + 电流 / 功率因数 + 灯状态 */
        sprintf(g_line1, "U=%3u.%1uV I=%u.%02uA",
                (uint)(g_U_d1 / 10), (uint)(g_U_d1 % 10),
                (uint)(g_I_c2 / 100), (uint)(g_I_c2 % 100));
        if (g_pfState == 1)
            sprintf(g_line2, "PF=%u.%02u  GREEN  ", (uint)(g_pf_d2 / 100), (uint)(g_pf_d2 % 100));
        else if (g_pfState == 2)
            sprintf(g_line2, "PF=%u.%02u  RED    ", (uint)(g_pf_d2 / 100), (uint)(g_pf_d2 % 100));
        else
            sprintf(g_line2, "PF=%u.%02u  NORMAL ", (uint)(g_pf_d2 / 100), (uint)(g_pf_d2 % 100));
        LCD_Write_Str(0, 0, g_line1);
        LCD_Write_Str(1, 0, g_line2);
    } else {
        /* 页2: 有功功率 + 视在功率 / 标题 */
        sprintf(g_line1, "P=%4uW S=%4uVA", (uint)g_P_w, (uint)g_S_va);
        LCD_Write_Str(0, 0, g_line1);
        LCD_Write_Str(1, 0, "1-Ph AC PwrMeter");
    }
}

/* ==================== main ==================== */
void main(void)
{
    uint adcTick  = ADC_TICKS;     /* 上电立即采一次 */
    uint lcdTick  = LCD_TICKS;
    uint pageTick = 0;

    /* 端口初值: 全 1 (51 准双向口写 1 才能读输入/释放总线) */
    P0 = 0xFF; P1 = 0xFF; P2 = 0xFF; P3 = 0xFF;
    LED_GRN = 0; LED_RED = 0;       /* 上电双灯灭 */
    TLC_CS = 1; TLC_CLK = 0; TLC_ADDR = 0;

    LCD_Init();

    /* 开机 banner 约 1.2s */
    LCD_Write_Str(0, 0, "1-Phase AC Meter");
    LCD_Write_Str(1, 0, "U/I/P/S/PF  v1.0");
    Delay_ms(1200);
    LCD_Write_Cmd(0x01);            /* 清屏 */
    Delay_ms(2);

    while (1)
    {
        if (++adcTick >= ADC_TICKS) {       /* 100ms: 采样 + 算功率 + 刷 LED (实时) */
            adcTick = 0;
            Sample_And_Compute();
            Update_LED();
        }
        if (++lcdTick >= LCD_TICKS) {       /* 250ms: 刷 LCD 当前页 */
            lcdTick = 0;
            LCD_ShowPage(g_page);
        }
        if (++pageTick >= PAGE_TICKS) {     /* 2.5s: 切换显示页 */
            pageTick = 0;
            g_page = (g_page == 0) ? 1 : 0;
        }
        Delay_ms(LOOP_MS);
    }
}
